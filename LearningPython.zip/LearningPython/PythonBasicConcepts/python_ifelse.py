score=75
if score>90:
    print("you are awarded")
elif score>85 and score<90:
    print("partially awarded")
elif score>70 and score<80:
    print("awarded with something")
else:
    print("not awarded")