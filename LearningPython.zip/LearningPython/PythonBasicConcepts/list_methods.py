# go to google and search for python documentation
#go to python tutorial
#search for data structures
#click on data structures

citiies=["pune", "mumbai", "ranchi", "pune"]
print(citiies)
# citiies.append("aayodya")
citiies.insert(1,"aayodya")
citiies.remove("mumbai") #if there are 2 same values then it will remove first one
# citiies.pop(0)
print(citiies.index("pune"))
print(citiies.count("pune"))
print(citiies.sort())
print(citiies)
print(citiies.reverse())
print(citiies)
new_cities=citiies.copy()
print(citiies)
print(new_cities)
print(new_cities.clear())