x="python world"
y="UAE"

print("welcome to "+x+" from "+y)
print("welcome to %s from %s" %(x,y))
print("welcome to {} from {}".format(x,y))
print("welcome to {1} from {0}".format(x,y))
print("welcome to {Programminglanguage} from {city}".format(Programminglanguage=x,city=y))
