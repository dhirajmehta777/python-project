x=10
y=20
z="" #empty string hence returns false
w=0 #no value is there hence returns false
#print(x>y)
print(bool(x>y))
print(bool(x))
print(bool(y))
print(bool(z))
print(bool(w))
