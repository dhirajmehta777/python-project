def addition(x,y):

    """
    doc-string:
    this is sample function for adding two numbers
    :param x: Integer
    :param y:
    :return:it will retyrn sum of 2 numbers
    """
    #the above one is call as doc string so that a third person can easily understand the code by
    #reffering doc string
    #how to create doc string just press "" twice exactly below function
    return x+y
z=addition(10,90)
print(z)