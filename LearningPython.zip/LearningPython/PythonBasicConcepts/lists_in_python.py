x=10 #it holds only one value
y="python" #it holds only one value

z=["a", "pycharm", 20.5, 100] #its a list holds multiple values with same as well as diff datatype
a=[10,20,30,30] #duplicate values are allowed in the lists
b=[10.2,10,15,59]

print(a[0])
print(b[1])
print(z[1])
print(type(z))
print(type(a))
print(type(b))
print(z[0:2])
print(z[0:4:2])
print(z[0:4:3])