print(5+8-2)
print(5+(8-2)) #here it will execute from left to right before that the paranthesis will execute
print(5**2+2+10) #here exponential execute first
print(5**(12-2)+10) #here paranthesis execute first
