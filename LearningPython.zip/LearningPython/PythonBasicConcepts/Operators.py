#Arithematic Operators
# x=15
# y=4
# print(x+y)
# print(x-y)
# print(x*y)
# print(x/y)
# print(x%y)
# print(x**y)
# print(x//y)

#Assignment Operators
# x=10
# x+=2
# print(x)
# x-=4
# print(x)
# x*=4
# print(x)
# x/=2
# print(x)
# x**=2
# print(x)

#Comparision Operators
# x=10
# y=6
# print(x==y)
# print(x!=y)
# print(x>y)
# print(x<y)
# print(x>=y)
# print(x<=y)

#logical operators
# x=10
# y=4
# print(x==y and x>y)
# print(x==y or x>y)

#Identity Operators
# x=["Python", "World"]
# y=["Python", "World"]
# print(x is y) #compares objects
# print(x==y) #compares contents of the list
# print(x is not y)

#Membership Operators(when we want to check wheather the values are in the list or not
# then we go for membership operator
# x=["Python", "World"]
# y=["Python", "World"]
# print("python" in x)
# print("oops" not in y)
# print("world" not in y)




