"""
range is a build in function
it generates sequence of numbers
"""

for x in range(10):#no need to define a list
    print(x)
print("========================================================")
for y in range(1,11):#no need to define a list
    print(y)
print("========================================================")
for z in range(1,11,2):#no need to define a list
    print(z)
print("========================================================")
for d in range(1,11,3):#no need to define a list
    print(d)