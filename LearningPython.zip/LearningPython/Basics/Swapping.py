#Swapping

x=10
y=20
print("Before Swapping Values Are: ", x,y)
x,y=y,x
print("After Swapping Values Are: ", x,y)
