#Single line comment we can do it by using ash symbol.
'''
this is for
multi line comment.
using single coats
'''
"""
Or we can use double coats for
multiline comments.
"""