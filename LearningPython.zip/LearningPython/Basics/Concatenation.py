#valid Statements
print(10+10)
print(10+10.5)
print("welcome"+"python")
print(10.5+10.5)
print(True+5)
print(True+True)
print(False+10)
####################################################################
#invalid statements type error
print(10+"welcome")
print(10.5+"python")
print(True+"pycharm")
