x=15 #int
y=15.5 #float
s="pycharm" #String
b=True #boolean

#To know the variable type:use type command
print(type(x))
print(type(y))
print(type(s))
print(type(b))
