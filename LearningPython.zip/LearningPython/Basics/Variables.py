a=10
b=10.5
name="python"
x=True

print(a)
print(b)
print(name)
print(x)

#this statement assign 100 to a, 10.5 to b, python to name. multiple values to multiple variables.
a,b,name=100,10.5,"python"
print(a,b,name)

#if multiple variables having same value
a=b=c=10
print(a,b,c)

#Swapping of two numbers
x=10
y=20
print(x,y)#Before swaping
y,x=x,y
print(x,y)#After Swaping



