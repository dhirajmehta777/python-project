print("Hello, welcome to python")
print("Hello, welcome to python learning")
print("Hello, welcome to python world")

x=10
y=120
print(x+y)